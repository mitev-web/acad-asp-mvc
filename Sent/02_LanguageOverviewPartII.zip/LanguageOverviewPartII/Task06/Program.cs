﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task06
{
    class Program
    {
        static void Main(string[] args)
        {
            //We are given a library of books. Define classes for the library and the books. 
            //The library should have name and a list of books. 
            //The books have title, author, publisher, year of publishing and ISBN. Keep the books in List<Book> 
            //(first find how to use the class System.Collections.Generic.List<T>).

        }
    }
}