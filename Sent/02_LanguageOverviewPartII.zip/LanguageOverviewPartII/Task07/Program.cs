﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Task06;

namespace Task07
{
    class Program
    {
        static void Main(string[] args)
        {
            //Implement methods for adding, searching by title and author, displaying and deleting books.\

            //I've added them in Task06
        
        }
    }
}
