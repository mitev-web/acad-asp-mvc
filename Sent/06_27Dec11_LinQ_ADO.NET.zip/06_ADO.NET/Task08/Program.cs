﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task08
{
    class Program
    {
        static void Main(string[] args)
        {
            //By inheriting the Employee entity class create a class which allows employees
            //    to access their corresponding territories as property of type EntitySet<T>.

        }
    }
}
