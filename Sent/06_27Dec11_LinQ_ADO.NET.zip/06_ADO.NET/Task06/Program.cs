﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task06
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create a database called NorthwindTwin with the same structure as Northwind 
            //using the features from ObjectContext. Find for the API for schema generation 
            //    in MSDN or in Google.

        }
    }
}
