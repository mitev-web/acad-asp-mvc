﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace ADO.NET
{
    class Program
    {
        static void Main(string[] args)
        {
            //Try to open two different data contexts and perform concurrent changes on 
            //the same records. What will happen at SaveChanges()? How to deal with it?



        }
    }
}
