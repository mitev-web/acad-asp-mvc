﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task10
{
    class Program
    {
        static void Main(string[] args)
        {
         //Create a stored procedures in the Northwind database for finding the total 
         // incomes for given supplier name and period (start date, end date). 
         //Implement a C# method that calls the stored procedure and returns the retuned record set.

        }
    }
}
