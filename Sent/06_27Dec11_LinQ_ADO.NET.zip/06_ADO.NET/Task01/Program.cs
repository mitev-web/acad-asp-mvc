﻿using System;
using System.Collections.Generic;
using System.Data.Objects;
using System.Linq;
using System.Text;


namespace ADO.NET
{
    class Task01
    {
        static void Main(string[] args)
        {
            //Using the Visual Studio Entity Framework designer create a ObjectContext 
            //for the Northwind database


        }
    }
}
