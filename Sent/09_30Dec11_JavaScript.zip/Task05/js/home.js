// JavaScript Document
	function setVisible(element){
		document.getElementById(element).style.display = 'block';
	}
	
	function setHidden(element){
		document.getElementById(element).style.display = 'none';
	}
	