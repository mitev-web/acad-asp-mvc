﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task04d
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] matrix = new int[4, 4];

            PopulateMatrix(matrix);

            PrintMatrix(matrix);
        }

        private static void PopulateMatrix(int[,] matrix)
        {

            int n = matrix.GetLength(0);
            int count = n * n;
            int positionX = 1;
            int positionY = 2;

            int direction = 0;
            int stepsCount = 1;
            int stepPosition = 0;
            int stepChange = 0;

            for (int i = 1; i < count + 1; i++)
            {
                matrix[positionY, positionX] = i;
                if (stepPosition < stepsCount)
                {
                    stepPosition++;
                }
                else
                {
                    stepPosition = 1;

                    if (stepChange == 1)
                    {
                        stepsCount++;
                    }
                    stepChange = (stepChange + 1) % 2;
                    direction = (direction + 1) % 4;
                }

                switch (direction)
                {
                    case 0:
                        positionY--;
                        break;
                    case 1:
                        positionX++;
                        break;
                    case 2:
                        positionY++;
                        break;
                    case 3:
                        positionX--;
                        break;
                }
            }
        }

        private static void PrintMatrix(int[,] matrix)
        {
            int n = matrix.GetLength(0);
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write("{0,3}", matrix[i, j]);
                }
                Console.WriteLine();
            }
        }
    }
}
