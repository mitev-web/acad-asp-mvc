﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task02
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter a positive integer");
            int n;
            int.TryParse(Console.ReadLine(), out n);
            SumFibonacciNumbers(n);
        }

        static void SumFibonacciNumbers(int count)
        {
            int a = 0;
            int b = 1;
            int currentFibonacciNumber = 0;
            int[] fiboNumbers = new int[count];


            for (int i = 0; i < count; i++)
            {
                fiboNumbers[i] = currentFibonacciNumber;

                currentFibonacciNumber = a + b;
                a = b;
                b = currentFibonacciNumber;
                Console.WriteLine(currentFibonacciNumber);

            }
            Console.WriteLine(fiboNumbers.Sum());
        }
    }
}
