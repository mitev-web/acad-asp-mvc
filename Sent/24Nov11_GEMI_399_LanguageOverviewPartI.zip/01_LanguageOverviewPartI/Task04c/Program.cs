﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task04c
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] matrix = new int[4, 4];

            PopulateMatrix(matrix);

            PrintMatrix(matrix);
        }

        private static void PopulateMatrix(int[,] matrix)
        {

            int n = matrix.GetLength(0);
            int count = n * n;
            int positionX = 0;
            int positionY = 0;


            int direction = 0;
            int currentStep = 0;
            int stepChange = 3;
            int rotateTimes = 0;

            for (int i = 1; i < 17; i++)
            {
                matrix[positionY, positionX] = i;

                if (currentStep == stepChange)
                {
                    currentStep = 1;
                    direction = (++direction) % 4;
                    rotateTimes++;
                    if (rotateTimes % 3 == 0 || rotateTimes % 2.5 == 0)
                    {
                        stepChange--;
                    }
                }
                else
                {
                    currentStep++;
                }


                switch (direction)
                {
                    case 0:
                        //go down
                        positionY++;
                        break;
                    case 1:
                        //go right
                        positionX++;
                        break;
                    case 2:
                        //go up
                        positionY--;
                        break;
                    case 3:
                        //go left
                        positionX--;
                        break;
                }
            }
        }
        private static void PrintMatrix(int[,] matrix)
        {
            int n = matrix.GetLength(0);
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write("{0,3}", matrix[i, j]);
                }
                Console.WriteLine();
            }
        }
    }
}
